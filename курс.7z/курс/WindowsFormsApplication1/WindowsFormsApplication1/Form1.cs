﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RDotNet;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            REngine engine;
            
            engine = REngine.GetInstance();
            double x1 = Convert.ToDouble(textBox1.Text);
            NumericVector X1 = null;
            X1= engine.CreateNumericVector(new double[]{x1});
            engine.SetSymbol("X1",X1);
            double x2 = Convert.ToDouble(textBox2.Text);
            NumericVector X2 = null;
            X2 = engine.CreateNumericVector(new double[] { x2 });
            engine.SetSymbol("X2", X2);
            double x3 = Convert.ToDouble(textBox3.Text);
            NumericVector X3 = null;
            X3 = engine.CreateNumericVector(new double[] { x3 });
            engine.SetSymbol("X3", X3);
            double x4 = Convert.ToDouble(textBox4.Text);
            NumericVector X4 = null;
            X4 = engine.CreateNumericVector(new double[] { x4 });
            engine.SetSymbol("X4", X4);
            double x5 = Convert.ToDouble(textBox5.Text);
            NumericVector X5 = null;
            X5 = engine.CreateNumericVector(new double[] { x5 });
            engine.SetSymbol("X5", X5);
            
            engine.Evaluate("load('C:/Users/a.a.mukhtarov/Desktop/pred.RData')");
            var ans = engine.Evaluate("pred(X1,X2,X3,X4,X5)").AsNumeric();
            var ans2 = Convert.ToString(ans[0]);
            textBox6.Text = ans2;
        }
    }
}
